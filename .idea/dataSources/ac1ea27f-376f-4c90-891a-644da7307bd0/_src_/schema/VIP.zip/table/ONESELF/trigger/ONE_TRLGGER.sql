create trigger ONE_TRLGGER
	before insert
	on ONESELF
	for each row
BEGIN 
    SELECT one_sequence.nextval INTO :NEW.OID FROM dual;
  END;